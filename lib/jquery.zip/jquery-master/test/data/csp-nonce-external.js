/* global startIframeTest */

jQuery( function() {
	$( "body" ).append( "<script nonce='jquery+hardcoded+nonce' src='csp-nonce.js'></script>" );
} );
